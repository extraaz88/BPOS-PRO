# Windows Responsive Design Guide

यह guide बताता है कि कैसे app को Windows के लिए responsive बनाया जाए।

## ✅ क्या Already Implemented है:

1. **ResponsiveHelper Utility** (`lib/utils/responsive_helper.dart`)
   - Screen size detection (Mobile, Tablet, Desktop)
   - Responsive padding, spacing, font sizes
   - Grid layouts के लिए responsive utilities

2. **Responsive Wrapper Widgets** (`lib/widgets/responsive_wrapper.dart`)
   - `ResponsiveScreenWrapper` - Screen को wrap करने के लिए
   - `ResponsiveGridView` - Responsive grid layouts
   - `ResponsiveSizedBox` - Responsive spacing
   - `ResponsiveText` - Responsive text sizes
   - `ResponsiveButton` - Responsive buttons

3. **Main.dart में Windows Support**
   - Windows-specific text scaling
   - Platform detection

## 📝 कैसे Use करें:

### 1. Screen को Responsive बनाना:

```dart
import 'package:mobile_pos/widgets/responsive_wrapper.dart';

@override
Widget build(BuildContext context) {
  return ResponsiveScreenWrapper(
    child: Scaffold(
      // Your screen content
    ),
  );
}
```

### 2. Responsive Spacing:

```dart
// Old way (hardcoded):
const SizedBox(width: 10)

// New way (responsive):
ResponsiveSizedBox(width: 10)
```

### 3. Responsive Text:

```dart
// Old way:
Text('Hello', style: TextStyle(fontSize: 16))

// New way:
ResponsiveText(
  'Hello',
  mobileFontSize: 16,
  tabletFontSize: 18,
  desktopFontSize: 20,
)
```

### 4. Responsive Grid:

```dart
// Old way:
GridView.builder(
  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
    crossAxisCount: 2, // Hardcoded
  ),
)

// New way:
ResponsiveGridView(
  children: items,
  mobileCrossAxisCount: 2,
  tabletCrossAxisCount: 3,
  desktopCrossAxisCount: 4,
)
```

### 5. Responsive Padding:

```dart
// Old way:
padding: EdgeInsets.all(16)

// New way:
padding: ResponsiveHelper.padding(context)
```

## 🎯 Key Screens जो Update होने चाहिए:

1. ✅ Home Screen - Partially done
2. ✅ Product List Screen - Wrapper added
3. ⏳ Sales Screen
4. ⏳ Purchase Screen
5. ⏳ Customer List Screen
6. ⏳ Invoice Details Screen
7. ⏳ Dashboard Screen

## 🔧 Best Practices:

1. **Hardcoded values avoid करें:**
   - `SizedBox(width: 10)` → `ResponsiveSizedBox(width: 10)`
   - `fontSize: 16` → `ResponsiveHelper.fontSize(context, mobile: 16)`

2. **Max Width set करें:**
   - Desktop पर content बहुत wide न हो, इसलिए `ResponsiveScreenWrapper` use करें

3. **Grid Layouts:**
   - Mobile: 2 columns
   - Tablet: 3 columns  
   - Desktop: 4-6 columns

4. **Font Sizes:**
   - Mobile: Base size
   - Tablet: Base * 1.2
   - Desktop: Base * 1.3-1.5

## 📱 Breakpoints:

- Mobile: < 600px
- Tablet: 600px - 1200px
- Desktop: >= 1200px
- Large Desktop: >= 1920px

## 🚀 Quick Start:

किसी भी screen को responsive बनाने के लिए:

1. `ResponsiveScreenWrapper` से wrap करें
2. Hardcoded spacing को `ResponsiveSizedBox` से replace करें
3. Hardcoded font sizes को `ResponsiveHelper.fontSize` से replace करें
4. Grid layouts को `ResponsiveGridView` से replace करें

## 📚 Examples:

### Example 1: Simple Screen
```dart
@override
Widget build(BuildContext context) {
  return ResponsiveScreenWrapper(
    child: Scaffold(
      appBar: AppBar(title: Text('My Screen')),
      body: Padding(
        padding: ResponsiveHelper.padding(context),
        child: Column(
          children: [
            ResponsiveText('Title', mobileFontSize: 24),
            ResponsiveSizedBox(height: 20),
            // Content
          ],
        ),
      ),
    ),
  );
}
```

### Example 2: Grid Layout
```dart
ResponsiveGridView(
  children: products.map((p) => ProductCard(p)).toList(),
  mobileCrossAxisCount: 2,
  tabletCrossAxisCount: 3,
  desktopCrossAxisCount: 4,
)
```

## ⚠️ Important Notes:

- Windows पर automatically responsive होगा
- Android/Mobile पर original behavior maintain होगा
- Gradually screens को update करें - सभी screens को एक साथ update करने की जरूरत नहीं

