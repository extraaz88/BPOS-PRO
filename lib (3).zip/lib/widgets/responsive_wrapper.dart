import 'dart:io';
import 'package:flutter/material.dart';
import '../utils/responsive_helper.dart';

/// Responsive Wrapper Widget for Windows
/// Wraps any screen to make it responsive for Windows desktop
class ResponsiveScreenWrapper extends StatelessWidget {
  final Widget child;
  final bool enableMaxWidth;
  final double? maxWidth;
  final EdgeInsets? padding;

  const ResponsiveScreenWrapper({
    Key? key,
    required this.child,
    this.enableMaxWidth = true,
    this.maxWidth,
    this.padding,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Only apply responsive wrapper on Windows
    if (!Platform.isWindows) {
      return child;
    }

    // Use LayoutBuilder to safely get constraints without triggering mouse tracker errors
    return LayoutBuilder(
      builder: (context, constraints) {
        return ResponsiveContainer(
          maxWidth: enableMaxWidth ? (maxWidth ?? ResponsiveHelper.maxContentWidth(context)) : null,
          padding: padding ?? ResponsiveHelper.horizontalPadding(context),
          child: child,
        );
      },
    );
  }
}

/// Responsive Grid View for Products/Items
class ResponsiveGridView extends StatelessWidget {
  final List<Widget> children;
  final int? mobileCrossAxisCount;
  final int? tabletCrossAxisCount;
  final int? desktopCrossAxisCount;
  final double? childAspectRatio;
  final double? spacing;

  const ResponsiveGridView({
    Key? key,
    required this.children,
    this.mobileCrossAxisCount,
    this.tabletCrossAxisCount,
    this.desktopCrossAxisCount,
    this.childAspectRatio,
    this.spacing,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: ResponsiveHelper.gridCrossAxisCount(
          context,
          mobile: mobileCrossAxisCount ?? 2,
          tablet: tabletCrossAxisCount ?? 3,
          desktop: desktopCrossAxisCount ?? 4,
          largeDesktop: 6,
        ),
        childAspectRatio: childAspectRatio ?? ResponsiveHelper.gridChildAspectRatio(context),
        crossAxisSpacing: spacing ?? ResponsiveHelper.gridSpacing(context),
        mainAxisSpacing: spacing ?? ResponsiveHelper.gridSpacing(context),
      ),
      itemCount: children.length,
      itemBuilder: (context, index) => children[index],
    );
  }
}

/// Responsive Row that adapts to screen size
class ResponsiveRow extends StatelessWidget {
  final List<Widget> children;
  final MainAxisAlignment mainAxisAlignment;
  final CrossAxisAlignment crossAxisAlignment;
  final double? spacing;

  const ResponsiveRow({
    Key? key,
    required this.children,
    this.mainAxisAlignment = MainAxisAlignment.start,
    this.crossAxisAlignment = CrossAxisAlignment.center,
    this.spacing,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final spacingValue = spacing ?? ResponsiveHelper.spacing(context);
    
    if (ResponsiveHelper.isMobile(context)) {
      // Stack vertically on mobile
      return Column(
        mainAxisAlignment: mainAxisAlignment == MainAxisAlignment.start 
            ? MainAxisAlignment.start 
            : mainAxisAlignment == MainAxisAlignment.end 
                ? MainAxisAlignment.end 
                : MainAxisAlignment.center,
        crossAxisAlignment: crossAxisAlignment,
        children: children
            .expand((child) => [
                  child,
                  SizedBox(height: spacingValue),
                ])
            .take(children.length * 2 - 1)
            .toList(),
      );
    }

    // Use Row for tablet and desktop
    return Row(
      mainAxisAlignment: mainAxisAlignment,
      crossAxisAlignment: crossAxisAlignment,
      children: children
          .expand((child) => [
                child,
                SizedBox(width: spacingValue),
              ])
          .take(children.length * 2 - 1)
          .toList(),
    );
  }
}

/// Responsive SizedBox that adapts to screen size
class ResponsiveSizedBox extends StatelessWidget {
  final double? width;
  final double? height;
  final double mobileMultiplier;
  final double tabletMultiplier;
  final double desktopMultiplier;

  const ResponsiveSizedBox({
    Key? key,
    this.width,
    this.height,
    this.mobileMultiplier = 1.0,
    this.tabletMultiplier = 1.2,
    this.desktopMultiplier = 1.5,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double? responsiveWidth;
    double? responsiveHeight;

    if (width != null) {
      if (ResponsiveHelper.isMobile(context)) {
        responsiveWidth = width! * mobileMultiplier;
      } else if (ResponsiveHelper.isTablet(context)) {
        responsiveWidth = width! * tabletMultiplier;
      } else {
        responsiveWidth = width! * desktopMultiplier;
      }
    }

    if (height != null) {
      if (ResponsiveHelper.isMobile(context)) {
        responsiveHeight = height! * mobileMultiplier;
      } else if (ResponsiveHelper.isTablet(context)) {
        responsiveHeight = height! * tabletMultiplier;
      } else {
        responsiveHeight = height! * desktopMultiplier;
      }
    }

    return SizedBox(
      width: responsiveWidth,
      height: responsiveHeight,
    );
  }
}

/// Responsive Text Widget
class ResponsiveText extends StatelessWidget {
  final String text;
  final TextStyle? style;
  final double? mobileFontSize;
  final double? tabletFontSize;
  final double? desktopFontSize;
  final TextAlign? textAlign;
  final int? maxLines;
  final TextOverflow? overflow;

  const ResponsiveText(
    this.text, {
    Key? key,
    this.style,
    this.mobileFontSize,
    this.tabletFontSize,
    this.desktopFontSize,
    this.textAlign,
    this.maxLines,
    this.overflow,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final fontSize = ResponsiveHelper.fontSize(
      context,
      mobile: mobileFontSize ?? style?.fontSize ?? 14,
      tablet: tabletFontSize,
      desktop: desktopFontSize,
    );

    return Text(
      text,
      style: style?.copyWith(fontSize: fontSize) ?? TextStyle(fontSize: fontSize),
      textAlign: textAlign,
      maxLines: maxLines,
      overflow: overflow,
    );
  }
}

/// Responsive Icon Widget
class ResponsiveIcon extends StatelessWidget {
  final IconData icon;
  final Color? color;
  final double? mobileSize;
  final double? tabletSize;
  final double? desktopSize;

  const ResponsiveIcon(
    this.icon, {
    Key? key,
    this.color,
    this.mobileSize,
    this.tabletSize,
    this.desktopSize,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final size = ResponsiveHelper.iconSize(
      context,
      mobile: mobileSize ?? 24,
      tablet: tabletSize,
      desktop: desktopSize,
    );

    return Icon(
      icon,
      size: size,
      color: color,
    );
  }
}

/// Responsive Button Widget
class ResponsiveButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final Color? backgroundColor;
  final Color? textColor;
  final double? mobileHeight;
  final double? tabletHeight;
  final double? desktopHeight;
  final double? mobileFontSize;
  final double? tabletFontSize;
  final double? desktopFontSize;
  final EdgeInsets? padding;

  const ResponsiveButton({
    Key? key,
    required this.text,
    this.onPressed,
    this.backgroundColor,
    this.textColor,
    this.mobileHeight,
    this.tabletHeight,
    this.desktopHeight,
    this.mobileFontSize,
    this.tabletFontSize,
    this.desktopFontSize,
    this.padding,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final height = ResponsiveHelper.buttonHeight(
      context,
      mobile: mobileHeight ?? 48,
      tablet: tabletHeight,
      desktop: desktopHeight,
    );

    final fontSize = ResponsiveHelper.fontSize(
      context,
      mobile: mobileFontSize ?? 16,
      tablet: tabletFontSize,
      desktop: desktopFontSize,
    );

    return SizedBox(
      height: height,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: backgroundColor ?? Theme.of(context).primaryColor,
          padding: padding ?? ResponsiveHelper.horizontalPadding(context, mobile: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(
              ResponsiveHelper.borderRadius(context),
            ),
          ),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: textColor ?? Colors.white,
            fontSize: fontSize,
          ),
        ),
      ),
    );
  }
}

