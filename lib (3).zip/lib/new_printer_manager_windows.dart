import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:flutter/foundation.dart'; 
import 'package:oktoast/oktoast.dart';
import 'dart:io';
import '../model/business_info_model.dart';
import '../thermal priting invoices/model/print_transaction_model.dart';
import '../PDF Invoice/sales_invoice_pdf.dart';
import '../PDF Invoice/purchase_invoice_pdf.dart';
import '../PDF Invoice/due_invoice_pdf.dart';
import '../Repository/API/business_info_repo.dart';

class PrinterIndicator extends StatelessWidget {
  final bool isConnected;
  final String? printerName;
  const PrinterIndicator({Key? key, required this.isConnected, this.printerName}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          isConnected ? Icons.print : Icons.print_disabled,
          color: isConnected ? Colors.green : Colors.red,
          size: 22,
        ),
        SizedBox(width: 6),
        Text(
          isConnected
              ? (printerName?.isNotEmpty == true ? printerName! : "Printer Connected")
              : "No Printer",
          style: TextStyle(
            color: isConnected ? Colors.green : Colors.red,
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
      ],
    );
  }
}

class printerexe extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'USB Printer Demo',
      home: Scaffold(
        appBar: AppBar(title: Text("USB Thermal Printer Test")),
        body: Center(
          child: ElevatedButton(
            child: Text("Print Receipt"),
            onPressed: () async {
              final pdf = pw.Document();

              pdf.addPage(
                pw.Page(
                  pageFormat: PdfPageFormat.roll57, 
                  build: (pw.Context context) {
                    return pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text("🧾 TEST RECEIPT",
                            style: pw.TextStyle(
                                fontSize: 18, fontWeight: pw.FontWeight.bold)),
                        pw.SizedBox(height: 10),
                        pw.Text("Hello from Flutter to USB Thermal Printer!"),
                        pw.SizedBox(height: 20),
                        pw.Text("Date: ${DateTime.now()}"),
                        pw.Divider(),
                        pw.Text("Thank you 🙏"),
                      ],
                    );
                  },
                ),
              );
              await Printing.layoutPdf(
                onLayout: (PdfPageFormat format) async => pdf.save(),
              );
            },
          ),
        ),
      ),
    );
  }
}
class PrinterSetupForWindows extends StatefulWidget {
  const PrinterSetupForWindows({super.key});

  @override
  State<PrinterSetupForWindows> createState() => _PrinterSetupForWindowsState();
}

class _PrinterSetupForWindowsState extends State<PrinterSetupForWindows> {
  bool isConnected = false;
  String? printerName;
  late final Ticker _ticker;
  // ignore: unused_field
  final Duration _checkInterval = Duration(seconds: 2);

  @override
  void initState() {
    super.initState();
    _ticker = Ticker(_checkPrinterStatus)..start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  void _checkPrinterStatus(Duration elapsed) async {}

  void _setConnected(bool connected, {String? name}) {
    setState(() {
      isConnected = connected;
      printerName = name;
    });
  }

  void _openPrinterPopup(BuildContext context) async {
    await showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      transitionDuration: const Duration(milliseconds: 400),
      pageBuilder: (context, anim1, anim2) {
        return ConnectPrinterPopup(
          onTestPrint: () {
            _setConnected(true, name: "USB Printer");
          },
          onDisconnect: () {
            _setConnected(false);
          },
        );
      },
      transitionBuilder: (context, anim1, anim2, child) {
        return SlideTransition(
          position: Tween(
            begin: const Offset(0, -1),
            end: Offset.zero,
          ).animate(CurvedAnimation(parent: anim1, curve: Curves.easeOut)),
          child: child,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Printers Setup',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: PrinterIndicator(
              isConnected: isConnected,
              printerName: printerName,
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Center(
          child: Container(
            height: 250,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: Colors.grey),
            ),
            child: Padding(
              padding: const EdgeInsets.only(
                top: 25,
                bottom: 35,
                left: 25,
                right: 25,
              ),
              child: InkWell(
                onTap: () => _openPrinterPopup(context),
                child: Container(
                  height: 200,
                  width: double.infinity,
                  color: const Color.fromARGB(255, 200, 192, 230),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.print,
                          size: 40,
                          color: Color.fromARGB(255, 68, 54, 150),
                        ),
                        SizedBox(height: 10),
                        Text(
                          'Printers',
                          style: TextStyle(
                            fontSize: 20,
                            color: Color.fromARGB(255, 68, 54, 150),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
class ConnectPrinterPopup extends StatelessWidget {
  final VoidCallback? onTestPrint;
  final VoidCallback? onDisconnect;
  const ConnectPrinterPopup({Key? key, this.onTestPrint, this.onDisconnect}) : super(key: key);

  void _showToast(BuildContext context, String msg, Color color) {
    showToast(
      msg,
      context: context,
      backgroundColor: color,
      textStyle: const TextStyle(color: Colors.white, fontSize: 16),
      position: ToastPosition.bottom,
      radius: 8,
      textPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      animationCurve: Curves.easeInOut,
      duration: const Duration(seconds: 2),
    );
  }

  Future<void> _printTestReceipt(BuildContext context) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.roll57,
        build: (pw.Context context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text("Hello, BharatPOS is ready for printing your bill"),
              pw.SizedBox(height: 20),
              pw.Text("Date: ${DateTime.now()}"),
              pw.Divider(),
              pw.Text("Thank you 🙏"),
            ],
          );
        },
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
    );

    _showToast(context, "Test print sent!", Colors.green);
    if (onTestPrint != null) onTestPrint!();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15),
      child: Align(
        child: Material(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            width: MediaQuery.of(context).size.width * 0.95,
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Connect Printer",
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                SizedBox(height: 20),
                Icon(Icons.print, size: 60, color: Colors.deepPurple),
                SizedBox(height: 30),
                ElevatedButton.icon(
                  icon: Icon(Icons.print),
                  label: Text("Test Print"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    padding:
                        EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                    textStyle: TextStyle(fontSize: 16),
                  ),
                  onPressed: () => _printTestReceipt(context),
                ),
                SizedBox(height: 30),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 134, 58, 148),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  onPressed: () {
                    if (onDisconnect != null) onDisconnect!();
                    Navigator.pop(context);
                  },
                  child: const Text(
                    "Close",
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Windows Print Helper - PDF-based printing for Windows platform
class WindowsPrintHelper {
  /// Print Sales Invoice on Windows - Shows Windows Print Dialog
  static Future<void> printSalesInvoice({
    required PrintTransactionModel transaction,
    required BuildContext context,
    required BusinessInformation businessInfo,
  }) async {
    if (!Platform.isWindows) {
      throw Exception('WindowsPrintHelper can only be used on Windows platform');
    }

    try {
      // Generate PDF using existing PDF generator
      final salesTransaction = transaction.transitionModel;
      if (salesTransaction == null) {
        throw Exception('Sales transaction is null');
      }

      // Get business settings from API
      final businessRepo = BusinessRepository();
      final businessSetting = await businessRepo.businessSettingData();
      
      // Generate PDF bytes using SalesInvoicePdf helper
      final pdfBytes = await SalesInvoicePdf.generateSaleDocumentBytes(
        salesTransaction,
        businessInfo,
        context,
        businessSetting,
      );
      
      // Show Windows print dialog (driver popup)
      await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => pdfBytes,
      );
    } catch (e) {
      print('Windows print error: $e');
      rethrow;
    }
  }


  /// Print Purchase Invoice on Windows
  static Future<void> printPurchaseInvoice({
    required PrintPurchaseTransactionModel transaction,
    required BuildContext context,
    required BusinessInformation businessInfo,
  }) async {
    if (!Platform.isWindows) {
      throw Exception('WindowsPrintHelper can only be used on Windows platform');
    }

    try {
      final purchaseTransaction = transaction.purchaseTransitionModel;
      if (purchaseTransaction == null) {
        throw Exception('Purchase transaction is null');
      }

      // Get business settings from API
      final businessRepo = BusinessRepository();
      final businessSetting = await businessRepo.businessSettingData();
      
      await PurchaseInvoicePDF.generatePurchaseDocument(
        purchaseTransaction,
        businessInfo,
        context,
        businessSetting,
        isShare: false,
      );
    } catch (e) {
      print('Windows print error: $e');
      rethrow;
    }
  }

  /// Print Due Invoice on Windows
  static Future<void> printDueInvoice({
    required PrintDueTransactionModel transaction,
    required BuildContext context,
    required BusinessInformation businessInfo,
  }) async {
    if (!Platform.isWindows) {
      throw Exception('WindowsPrintHelper can only be used on Windows platform');
    }

    try {
      final dueTransaction = transaction.dueTransactionModel;
      if (dueTransaction == null) {
        throw Exception('Due transaction is null');
      }

      // Get business settings from API
      final businessRepo = BusinessRepository();
      final businessSetting = await businessRepo.businessSettingData();
      
      await DueInvoicePDF.generateDueDocument(
        dueTransaction,
        businessInfo,
        context,
        businessSetting,
        isShare: false,
      );
    } catch (e) {
      print('Windows print error: $e');
      rethrow;
    }
  }

  /// Check if running on Windows
  static bool get isWindows => Platform.isWindows;
}
