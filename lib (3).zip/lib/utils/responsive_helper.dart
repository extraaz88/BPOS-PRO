import 'dart:io';
import 'package:flutter/material.dart';

/// Responsive Helper for Windows and other platforms
/// Provides responsive utilities for different screen sizes
class ResponsiveHelper {
  // Breakpoints for different screen sizes
  static const double mobileBreakpoint = 600;
  static const double tabletBreakpoint = 900;
  static const double desktopBreakpoint = 1200;
  static const double largeDesktopBreakpoint = 1920;

  /// Get screen width (safe for Windows mouse tracking)
  /// Uses LayoutBuilder constraints when available to avoid mouse tracker errors
  static double screenWidth(BuildContext context) {
    // Use MediaQuery.maybeOf to safely get size without triggering errors
    final mediaQuery = MediaQuery.maybeOf(context);
    if (mediaQuery != null) {
      return mediaQuery.size.width;
    }
    // Fallback for when MediaQuery is not available
    return 800.0;
  }

  /// Get screen height (safe for Windows mouse tracking)
  /// Uses LayoutBuilder constraints when available to avoid mouse tracker errors
  static double screenHeight(BuildContext context) {
    // Use MediaQuery.maybeOf to safely get size without triggering errors
    final mediaQuery = MediaQuery.maybeOf(context);
    if (mediaQuery != null) {
      return mediaQuery.size.height;
    }
    // Fallback for when MediaQuery is not available
    return 600.0;
  }

  /// Check if running on Windows
  static bool isWindows() {
    return Platform.isWindows;
  }

  /// Check if screen is mobile
  static bool isMobile(BuildContext context) {
    return screenWidth(context) < mobileBreakpoint;
  }

  /// Check if screen is tablet
  static bool isTablet(BuildContext context) {
    final width = screenWidth(context);
    return width >= mobileBreakpoint && width < desktopBreakpoint;
  }

  /// Check if screen is desktop
  static bool isDesktop(BuildContext context) {
    return screenWidth(context) >= desktopBreakpoint;
  }

  /// Check if screen is large desktop
  static bool isLargeDesktop(BuildContext context) {
    return screenWidth(context) >= largeDesktopBreakpoint;
  }

  /// Get responsive width (percentage based)
  static double width(BuildContext context, double percentage) {
    return screenWidth(context) * (percentage / 100);
  }

  /// Get responsive height (percentage based)
  static double height(BuildContext context, double percentage) {
    return screenHeight(context) * (percentage / 100);
  }

  /// Get responsive font size
  static double fontSize(BuildContext context, {
    double mobile = 14,
    double? tablet,
    double? desktop,
    double? largeDesktop,
  }) {
    if (isMobile(context)) return mobile;
    if (isTablet(context)) return tablet ?? mobile * 1.2;
    if (isLargeDesktop(context)) return largeDesktop ?? desktop ?? mobile * 1.5;
    return desktop ?? mobile * 1.3;
  }

  /// Get responsive padding
  static EdgeInsets padding(BuildContext context, {
    double mobile = 16,
    double? tablet,
    double? desktop,
    double? largeDesktop,
  }) {
    double paddingValue;
    if (isMobile(context)) {
      paddingValue = mobile;
    } else if (isTablet(context)) {
      paddingValue = tablet ?? mobile * 1.5;
    } else if (isLargeDesktop(context)) {
      paddingValue = largeDesktop ?? desktop ?? mobile * 2.5;
    } else {
      paddingValue = desktop ?? mobile * 2;
    }
    return EdgeInsets.all(paddingValue);
  }

  /// Get responsive horizontal padding
  static EdgeInsets horizontalPadding(BuildContext context, {
    double mobile = 16,
    double? tablet,
    double? desktop,
    double? largeDesktop,
  }) {
    double paddingValue;
    if (isMobile(context)) {
      paddingValue = mobile;
    } else if (isTablet(context)) {
      paddingValue = tablet ?? mobile * 1.5;
    } else if (isLargeDesktop(context)) {
      paddingValue = largeDesktop ?? desktop ?? mobile * 2.5;
    } else {
      paddingValue = desktop ?? mobile * 2;
    }
    return EdgeInsets.symmetric(horizontal: paddingValue);
  }

  /// Get responsive vertical padding
  static EdgeInsets verticalPadding(BuildContext context, {
    double mobile = 16,
    double? tablet,
    double? desktop,
    double? largeDesktop,
  }) {
    double paddingValue;
    if (isMobile(context)) {
      paddingValue = mobile;
    } else if (isTablet(context)) {
      paddingValue = tablet ?? mobile * 1.5;
    } else if (isLargeDesktop(context)) {
      paddingValue = largeDesktop ?? desktop ?? mobile * 2.5;
    } else {
      paddingValue = desktop ?? mobile * 2;
    }
    return EdgeInsets.symmetric(vertical: paddingValue);
  }

  /// Get responsive spacing
  static double spacing(BuildContext context, {
    double mobile = 8,
    double? tablet,
    double? desktop,
    double? largeDesktop,
  }) {
    if (isMobile(context)) return mobile;
    if (isTablet(context)) return tablet ?? mobile * 1.5;
    if (isLargeDesktop(context)) return largeDesktop ?? desktop ?? mobile * 2.5;
    return desktop ?? mobile * 2;
  }

  /// Get responsive grid cross axis count
  static int gridCrossAxisCount(BuildContext context, {
    int mobile = 2,
    int? tablet,
    int? desktop,
    int? largeDesktop,
  }) {
    if (isMobile(context)) return mobile;
    if (isTablet(context)) return tablet ?? 3;
    if (isLargeDesktop(context)) return largeDesktop ?? desktop ?? 6;
    return desktop ?? 4;
  }

  /// Get responsive container width
  static double containerWidth(BuildContext context, {
    double? mobile,
    double? tablet,
    double? desktop,
    double? largeDesktop,
  }) {
    final screenWidth = ResponsiveHelper.screenWidth(context);
    
    if (isMobile(context)) {
      return mobile ?? screenWidth * 0.95;
    } else if (isTablet(context)) {
      return tablet ?? screenWidth * 0.85;
    } else if (isLargeDesktop(context)) {
      return largeDesktop ?? desktop ?? 1400;
    } else {
      return desktop ?? 1200;
    }
  }

  /// Get responsive max width for content
  static double maxContentWidth(BuildContext context) {
    if (isMobile(context)) return double.infinity;
    if (isTablet(context)) return 900;
    if (isLargeDesktop(context)) return 1600;
    return 1200;
  }

  /// Get responsive icon size
  static double iconSize(BuildContext context, {
    double mobile = 24,
    double? tablet,
    double? desktop,
    double? largeDesktop,
  }) {
    if (isMobile(context)) return mobile;
    if (isTablet(context)) return tablet ?? mobile * 1.2;
    if (isLargeDesktop(context)) return largeDesktop ?? desktop ?? mobile * 1.5;
    return desktop ?? mobile * 1.3;
  }

  /// Get responsive button height
  static double buttonHeight(BuildContext context, {
    double mobile = 48,
    double? tablet,
    double? desktop,
    double? largeDesktop,
  }) {
    if (isMobile(context)) return mobile;
    if (isTablet(context)) return tablet ?? mobile * 1.1;
    if (isLargeDesktop(context)) return largeDesktop ?? desktop ?? mobile * 1.3;
    return desktop ?? mobile * 1.2;
  }

  /// Get responsive border radius
  static double borderRadius(BuildContext context, {
    double mobile = 8,
    double? tablet,
    double? desktop,
    double? largeDesktop,
  }) {
    if (isMobile(context)) return mobile;
    if (isTablet(context)) return tablet ?? mobile * 1.2;
    if (isLargeDesktop(context)) return largeDesktop ?? desktop ?? mobile * 1.5;
    return desktop ?? mobile * 1.3;
  }

  /// Get responsive dialog width
  static double dialogWidth(BuildContext context) {
    if (isMobile(context)) return screenWidth(context) * 0.9;
    if (isTablet(context)) return 500;
    return 600;
  }

  /// Get responsive dialog height
  static double? dialogHeight(BuildContext context) {
    if (isMobile(context)) return null; // Auto height on mobile
    return 600;
  }

  /// Get responsive card padding
  static EdgeInsets cardPadding(BuildContext context) {
    return padding(context,
      mobile: 12,
      tablet: 16,
      desktop: 20,
      largeDesktop: 24,
    );
  }

  /// Get responsive grid spacing
  static double gridSpacing(BuildContext context) {
    return spacing(context,
      mobile: 8,
      tablet: 12,
      desktop: 16,
      largeDesktop: 20,
    );
  }

  /// Get responsive child aspect ratio for grid
  static double gridChildAspectRatio(BuildContext context, {
    double mobile = 0.75,
    double? tablet,
    double? desktop,
    double? largeDesktop,
  }) {
    if (isMobile(context)) return mobile;
    if (isTablet(context)) return tablet ?? 0.8;
    if (isLargeDesktop(context)) return largeDesktop ?? desktop ?? 1.0;
    return desktop ?? 0.9;
  }
}

/// Responsive Widget Builder
class ResponsiveBuilder extends StatelessWidget {
  final Widget Function(BuildContext context, bool isMobile, bool isTablet, bool isDesktop) builder;

  const ResponsiveBuilder({
    Key? key,
    required this.builder,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isMobile = ResponsiveHelper.isMobile(context);
    final isTablet = ResponsiveHelper.isTablet(context);
    final isDesktop = ResponsiveHelper.isDesktop(context);
    
    return builder(context, isMobile, isTablet, isDesktop);
  }
}

/// Responsive Container that adapts to screen size
class ResponsiveContainer extends StatelessWidget {
  final Widget child;
  final double? maxWidth;
  final EdgeInsets? padding;
  final AlignmentGeometry? alignment;

  const ResponsiveContainer({
    Key? key,
    required this.child,
    this.maxWidth,
    this.padding,
    this.alignment,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: alignment ?? Alignment.center,
      constraints: BoxConstraints(
        maxWidth: maxWidth ?? ResponsiveHelper.maxContentWidth(context),
      ),
      padding: padding ?? ResponsiveHelper.padding(context),
      child: child,
    );
  }
}

