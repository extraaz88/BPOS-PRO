class APIConfig {
  static String domain = 'https://app.bharatposretail.com/';
  static String url = '${domain}api/v1';
  static String registerUrl = '/sign-up';
  static String businessCategoriesUrl = '/business-categories';
}
