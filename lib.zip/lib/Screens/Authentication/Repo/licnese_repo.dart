import 'package:http/http.dart' as http;

import '../../../constant.dart';

class PurchaseModel {
  Future<bool> isActiveBuyer() async {
    return true; 
  }
}