import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../constant.dart';

class DashboardToggleSettingsDialog extends StatefulWidget {
  const DashboardToggleSettingsDialog({super.key});

  @override
  State<DashboardToggleSettingsDialog> createState() =>
      _DashboardToggleSettingsDialogState();
}

class _DashboardToggleSettingsDialogState
    extends State<DashboardToggleSettingsDialog> {
  bool _isToggleEnabled = false;
  bool _restrictZeroStockTransactions = false;

  @override
  void initState() {
    super.initState();
    _loadToggleSetting();
  }

  Future<void> _loadToggleSetting() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _isToggleEnabled =
          prefs.getBool('dashboard_payment_toggle_enabled') ?? false;
      _restrictZeroStockTransactions =
          prefs.getBool(kZeroStockRestrictionKey) ?? false;
    });
  }

  Future<void> _saveToggleSetting(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('dashboard_payment_toggle_enabled', value);
    if (!mounted) return;
    setState(() {
      _isToggleEnabled = value;
    });
  }

  Future<void> _saveZeroStockSetting(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kZeroStockRestrictionKey, value);
    if (!mounted) return;
    setState(() {
      _restrictZeroStockTransactions = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text(
        'Dashboard Toggle Settings',
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: kTitleColor,
        ),
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Enable payment method toggles on dashboard',
            style: TextStyle(
              fontSize: 14,
              color: kGreyTextColor,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Show Payment Method Toggles',
                style: TextStyle(
                  fontSize: 16,
                  color: kTitleColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Switch(
                value: _isToggleEnabled,
                activeColor: kMainColor,
                onChanged: _saveToggleSetting,
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            _isToggleEnabled
                ? 'Payment method toggles will be visible on dashboard'
                : 'Payment method toggles will be hidden on dashboard',
            style: const TextStyle(
              fontSize: 12,
              color: kGreyTextColor,
              fontStyle: FontStyle.italic,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Control product sale/purchase when stock is zero or marked out-of-stock',
            style: TextStyle(
              fontSize: 14,
              color: kGreyTextColor,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Expanded(
                child: Text(
                  'Prevent Out-of-Stock Transactions',
                  style: TextStyle(
                    fontSize: 16,
                    color: kTitleColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              Switch(
                value: _restrictZeroStockTransactions,
                activeColor: kMainColor,
                onChanged: _saveZeroStockSetting,
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            _restrictZeroStockTransactions
                ? 'Out-of-stock items cannot be added to Sale or Purchase carts.'
                : 'Out-of-stock items can still be sold or purchased.',
            style: const TextStyle(
              fontSize: 12,
              color: kGreyTextColor,
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: const Text(
            'Close',
            style: TextStyle(color: kMainColor),
          ),
        ),
      ],
    );
  }
}
