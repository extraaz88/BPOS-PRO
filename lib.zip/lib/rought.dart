import 'package:flutter/material.dart';
import 'package:showcaseview/showcaseview.dart';



class HomeScreen5 extends StatefulWidget {
  @override
  State<HomeScreen5> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen5> {
  // Showcase के लिए unique keys
  final GlobalKey _drawerHomeKey = GlobalKey();
  final GlobalKey _drawerProfileKey = GlobalKey();
  final GlobalKey _appBarNotifyKey = GlobalKey();

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();

    // Showcase को तब start करते हैं जब frame बन जाए
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      // Drawer पहले open करें ताकि अंदर के items दिखाई दें
      _scaffoldKey.currentState?.openDrawer();

      await Future.delayed(const Duration(milliseconds: 400));

      // Showcase शुरू करें
      ShowCaseWidget.of(context)?.startShowCase([
        _drawerHomeKey,
        _drawerProfileKey,
        _appBarNotifyKey,
      ]);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: const Text('Home Screen'),
        backgroundColor: Colors.blue,
        actions: [
          Showcase(
            key: _appBarNotifyKey,
            description: "यहाँ से आप notifications देख सकते हैं",
            child: IconButton(
              icon: const Icon(Icons.notifications),
              onPressed: () {},
            ),
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                'App Menu',
                style: TextStyle(color: Colors.white, fontSize: 22),
              ),
            ),
            Showcase(
              key: _drawerHomeKey,
              description: "यहाँ से Home page पर जाएँ",
              child: ListTile(
                leading: const Icon(Icons.home),
                title: const Text('Home'),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            ),
            Showcase(
              key: _drawerProfileKey,
              description: "यहाँ से आप Profile देख सकते हैं",
              child: ListTile(
                leading: const Icon(Icons.person),
                title: const Text('Profile'),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            ),
            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text('Settings'),
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
      body: const Center(
        child: Text(
          "Welcome to Home Screen 👋",
          style: TextStyle(fontSize: 20),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Showcase manually फिर से दिखाने के लिए
          ShowCaseWidget.of(context)?.startShowCase([
            _drawerHomeKey,
            _drawerProfileKey,
            _appBarNotifyKey,
          ]);
        },
        child: const Icon(Icons.play_arrow),
      ),
    );
  }
}
