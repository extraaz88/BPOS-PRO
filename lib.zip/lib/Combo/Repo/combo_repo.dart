import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'package:mobile_pos/Screens/Products/Model/product_model.dart';

import '../../../Const/api_config.dart';
import '../../../Repository/constant_functions.dart';
import '../../../http_client/custome_http_client.dart';
import '../Model/combo_model.dart';

class ComboRepo {
  double _roundToTwo(num value) => double.parse(value.toStringAsFixed(2));

  double _calculateTaxAmount(ProductModel product) {
    final gstType = product.gstType?.toLowerCase().trim();
    if (gstType == 'non-taxable' ||
        gstType == 'non taxable' ||
        gstType == 'exempt') {
      return 0;
    }

    double taxAmount = (product.vatAmount ?? 0).toDouble();

    if (taxAmount == 0) {
      final rateStr = product.gstRateSelect?.toString().trim();
      if (rateStr != null &&
          rateStr.isNotEmpty &&
          rateStr.toLowerCase() != 'n/a' &&
          rateStr.toLowerCase() != 'null') {
        final rate = num.tryParse(rateStr);
        if (rate != null && rate > 0) {
          final basePrice = (product.productSalePrice ?? 0).toDouble();
          taxAmount = (basePrice * rate.toDouble()) / 100.0;
        }
      }
    }

    return _roundToTwo(taxAmount);
  }

  double _priceWithTax(ProductModel product) {
    final basePrice = (product.productSalePrice ?? 0).toDouble();
    final taxAmount = _calculateTaxAmount(product);
    final vatType = product.vatType?.toLowerCase().trim();

    if (vatType == 'inclusive') {
      return _roundToTwo(basePrice);
    }

    return _roundToTwo(basePrice + taxAmount);
  }

  Future<List<ComboModel>> fetchAllCombos() async {
    final uri = Uri.parse('${APIConfig.url}/combo-kits');

    print('=== COMBO LIST API CALL ===');
    print('Method: GET');
    print('URL: ${uri.toString()}');
    print('Timestamp: ${DateTime.now()}');

    final response = await http.get(uri, headers: {
      'Accept': 'application/json',
      'Authorization': await getAuthToken(),
    });

    print('=== COMBO LIST API RESPONSE ===');
    print('Status Code: ${response.statusCode}');
    print('Response Body: ${response.body}');

    if (response.statusCode == 200) {
      final parsedData = jsonDecode(response.body) as Map<String, dynamic>;
      final productList = parsedData['data'] as List<dynamic>;

      print('=== COMBO LIST PARSED ===');
      print('Total Products: ${productList.length}');

      // Extract combo_kit from each product object and include product_status
      final comboList = productList
          .where((product) =>
              product is Map<String, dynamic> &&
              product.containsKey('combo_kit'))
          .map((product) {
        final productMap = product as Map<String, dynamic>;
        final comboKit = productMap['combo_kit'] as Map<String, dynamic>;

        // Debug: Check what keys are available in productMap
        print('Product map keys: ${productMap.keys.toList()}');
        final productStatusRaw = productMap['product_status'];
        print('product_status value: "$productStatusRaw"');
        print(
            'product_status type: ${productStatusRaw?.runtimeType ?? "null"}');

        // Include product_status and product_id from the parent product object
        final comboJson = Map<String, dynamic>.from(comboKit);
        final productStatus = productMap['product_status'];
        final productId = productMap['id']; // Outer product id
        comboJson['product_status'] = productStatus;
        comboJson['product_id'] = productId; // Store outer product id

        // Ensure productId is properly set (handle both num and int)
        if (productId != null) {
          print(
              'Product ID extracted: $productId (type: ${productId.runtimeType})');
        } else {
          print(
              'WARNING: Product ID is null for combo: ${comboJson['combo_name']}');
        }

        // Debug: Log product_status and product_id extraction
        print(
            'Extracting combo: ${comboJson['combo_name']}, product_status: "$productStatus", product_id: "$productId"');
        print(
            'Combo JSON before parsing - product_status: "${comboJson['product_status']}", product_id: "${comboJson['product_id']}"');

        final comboModel = ComboModel.fromJson(comboJson);
        print(
            'After parsing - combo.productStatus: "${comboModel.productStatus}", combo.productId: "${comboModel.productId}", combo.id: "${comboModel.id}"');

        return comboModel;
      }).toList();

      print('Total Combos extracted: ${comboList.length}');

      return comboList;
    } else {
      print('=== COMBO LIST ERROR ===');
      print('Failed to load combos: ${response.statusCode}');
      print('Response body: ${response.body}');
      throw Exception('Failed to load combos: ${response.statusCode}');
    }
  }

  Future<ComboModel?> getComboById(num comboId) async {
    final uri = Uri.parse('${APIConfig.url}/combo-kits/$comboId');

    print('=== GET COMBO BY ID API CALL ===');
    print('Method: GET');
    print('URL: ${uri.toString()}');
    print('Combo ID: $comboId');

    final response = await http.get(uri, headers: {
      'Accept': 'application/json',
      'Authorization': await getAuthToken(),
    });

    print('=== GET COMBO BY ID RESPONSE ===');
    print('Status Code: ${response.statusCode}');
    print('Response Body: ${response.body}');

    if (response.statusCode == 200) {
      final parsedData = jsonDecode(response.body) as Map<String, dynamic>;
      return ComboModel.fromJson(parsedData['data']);
    } else {
      throw Exception('Failed to load combo');
    }
  }

  Future<void> createCombo({
    required WidgetRef ref,
    required BuildContext context,
    required String comboName,
    required List<ProductModel> selectedProducts,
    required Map<String, int> productQuantities,
    required num subtotal,
    required String discountType,
    required num discountValue,
    required num finalPrice,
    File? image,
  }) async {
    final uri = Uri.parse('${APIConfig.url}/combo-kits');

    print('=== CREATE COMBO API CALL ===');
    print('Method: POST');
    print('URL: ${uri.toString()}');
    print('Timestamp: ${DateTime.now()}');

    try {
      var request = http.MultipartRequest("POST", uri);
      CustomHttpClient customHttpClient =
          CustomHttpClient(client: http.Client(), ref: ref, context: context);

      request.headers.addAll({
        "Accept": 'application/json',
        'Authorization': await getAuthToken(),
      });

      // Basic fields - matching API format
      request.fields['combo name'] = comboName;
      request.fields['discount_type'] = discountType;
      request.fields['discountAmount'] = discountValue.toString();
      request.fields['subtotal'] = subtotal.toString();
      request.fields['combo_price'] = finalPrice.toString();

      // Products array - format: [{"product_id":14,"product_price":300,"quantity":1}]
      final productsJson = selectedProducts.map((product) {
        final productIdStr = product.id?.toString() ?? '';
        final quantity = productQuantities[productIdStr] ?? 1;
        final priceWithTax = _priceWithTax(product);
        return {
          'product_id': product.id?.toInt() ?? 0,
          'product_price': priceWithTax,
          'quantity': quantity,
        };
      }).toList();
      request.fields['products'] = jsonEncode(productsJson);

      // Add image if provided
      if (image != null) {
        request.files.add(http.MultipartFile.fromBytes(
            'combo_image', image.readAsBytesSync(),
            filename: image.path.split('/').last));
        print('Image attached: ${image.path.split('/').last}');
      }

      // Log request body
      print('=== CREATE COMBO REQUEST BODY ===');
      print('Form Fields:');
      request.fields.forEach((key, value) {
        print('  $key: $value');
      });
      print('Total Fields: ${request.fields.length}');
      print('Files Count: ${request.files.length}');
      if (request.files.isNotEmpty) {
        for (var file in request.files) {
          print(
              '  File: ${file.field} - ${file.filename} (${file.length} bytes)');
        }
      }
      print('=== END REQUEST BODY ===');

      final response = await customHttpClient.uploadFile(
        url: uri,
        file: image,
        fileFieldName: 'combo_image',
        fields: request.fields,
      );

      final responseData = await response.stream.bytesToString();

      print('=== CREATE COMBO API RESPONSE ===');
      print('Status Code: ${response.statusCode}');
      print('Response Headers: ${response.headers}');
      print('Response Body: $responseData');
      print('=== END RESPONSE ===');

      final parsedData = jsonDecode(responseData);

      if (response.statusCode == 200 || response.statusCode == 201) {
        EasyLoading.showSuccess('Combo created successfully!');
        Navigator.pop(context);
        Navigator.pop(context); // Pop twice to go back to combo list
      } else {
        EasyLoading.showError(
            parsedData['message'] ?? 'Failed to create combo');
      }
    } catch (e, stackTrace) {
      print('=== CREATE COMBO ERROR ===');
      print('Error: $e');
      print('StackTrace: $stackTrace');
      EasyLoading.showError('Error creating combo: $e');
    }
  }

  Future<void> updateCombo({
    required WidgetRef ref,
    required BuildContext context,
    required num comboId,
    required String comboName,
    required List<ProductModel> selectedProducts,
    required Map<String, int> productQuantities,
    required num subtotal,
    required String discountType,
    required num discountValue,
    required num finalPrice,
    File? image,
  }) async {
    final uri = Uri.parse('${APIConfig.url}/combo-kits/$comboId');

    print('=== UPDATE COMBO API CALL ===');
    print('Method: PUT (via POST with _method)');
    print('URL: ${uri.toString()}');
    print('Combo ID: $comboId');
    print('Timestamp: ${DateTime.now()}');

    try {
      var request = http.MultipartRequest("POST", uri);
      CustomHttpClient customHttpClient =
          CustomHttpClient(client: http.Client(), ref: ref, context: context);

      request.headers.addAll({
        "Accept": 'application/json',
        'Authorization': await getAuthToken(),
      });

      request.fields['_method'] = 'PUT';

      // Basic fields - matching API format
      request.fields['combo name'] = comboName;
      request.fields['discount_type'] = discountType;
      request.fields['discountAmount'] = discountValue.toString();
      request.fields['subtotal'] = subtotal.toString();
      request.fields['combo_price'] = finalPrice.toString();

      // Products array - format: [{"product_id":14,"product_price":300,"quantity":1}]
      final productsJson = selectedProducts.map((product) {
        final productIdStr = product.id?.toString() ?? '';
        final quantity = productQuantities[productIdStr] ?? 1;
        final priceWithTax = _priceWithTax(product);
        return {
          'product_id': product.id?.toInt() ?? 0,
          'product_price': priceWithTax,
          'quantity': quantity,
        };
      }).toList();
      request.fields['products'] = jsonEncode(productsJson);

      // Add image if provided
      if (image != null) {
        request.files.add(http.MultipartFile.fromBytes(
            'combo_image', image.readAsBytesSync(),
            filename: image.path.split('/').last));
        print('Image attached: ${image.path.split('/').last}');
      }

      // Log request body
      print('=== UPDATE COMBO REQUEST BODY ===');
      print('Form Fields:');
      request.fields.forEach((key, value) {
        print('  $key: $value');
      });
      print('Total Fields: ${request.fields.length}');
      print('Files Count: ${request.files.length}');
      if (request.files.isNotEmpty) {
        for (var file in request.files) {
          print(
              '  File: ${file.field} - ${file.filename} (${file.length} bytes)');
        }
      }
      print('=== END REQUEST BODY ===');

      final response = await customHttpClient.uploadFile(
        url: uri,
        file: image,
        fileFieldName: 'combo_image',
        fields: request.fields,
      );

      final responseData = await response.stream.bytesToString();

      print('=== UPDATE COMBO API RESPONSE ===');
      print('Status Code: ${response.statusCode}');
      print('Response Headers: ${response.headers}');
      print('Response Body: $responseData');
      print('=== END RESPONSE ===');

      final parsedData = jsonDecode(responseData);

      if (response.statusCode == 200) {
        EasyLoading.showSuccess('Combo updated successfully!');
        Navigator.pop(context);
        Navigator.pop(context);
      } else {
        EasyLoading.showError(
            parsedData['message'] ?? 'Failed to update combo');
      }
    } catch (e, stackTrace) {
      print('=== UPDATE COMBO ERROR ===');
      print('Error: $e');
      print('StackTrace: $stackTrace');
      EasyLoading.showError('Error updating combo: $e');
    }
  }

  Future<void> deleteCombo({
    required WidgetRef ref,
    required BuildContext context,
    required num comboId,
  }) async {
    final uri = Uri.parse('${APIConfig.url}/combo-kits/$comboId');

    print('=== DELETE COMBO API CALL ===');
    print('Method: DELETE');
    print('URL: ${uri.toString()}');
    print('Combo ID: $comboId');
    print('Timestamp: ${DateTime.now()}');

    try {
      final response = await http.delete(uri, headers: {
        'Accept': 'application/json',
        'Authorization': await getAuthToken(),
      });

      print('=== DELETE COMBO API RESPONSE ===');
      print('Status Code: ${response.statusCode}');
      print('Response Body: ${response.body}');
      print('=== END RESPONSE ===');

      if (response.statusCode == 200) {
        EasyLoading.showSuccess('Combo deleted successfully!');
      } else {
        final parsedData = jsonDecode(response.body);
        EasyLoading.showError(
            parsedData['message'] ?? 'Failed to delete combo');
      }
    } catch (e, stackTrace) {
      print('=== DELETE COMBO ERROR ===');
      print('Error: $e');
      print('StackTrace: $stackTrace');
      EasyLoading.showError('Error deleting combo: $e');
    }
  }

  Future<void> updateComboStatus({
    required num comboId,
    required num productId,
    required String status, // 'active' or 'inactive'
    num? comboProductId, // The ID of the combo_product relationship
  }) async {
    final uri = Uri.parse('${APIConfig.url}/combo-kits/$comboId/status');

    print('=== UPDATE COMBO STATUS API CALL ===');
    print('Method: POST');
    print('URL: ${uri.toString()}');
    print('Combo ID: $comboId');
    print('Product ID: $productId');
    if (comboProductId != null) {
      print('Combo Product ID: $comboProductId');
    }
    print('Status: $status');
    print('Timestamp: ${DateTime.now()}');

    try {
      final response = await http.put(
        uri,
        headers: {
          'Accept': 'application/json',
          'Authorization': await getAuthToken(),
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'product_id': productId,
          'status': status,
        }),
      );

      print('=== UPDATE COMBO STATUS API RESPONSE ===');
      print('Status Code: ${response.statusCode}');
      print('Response Body: ${response.body}');
      print('Combo ID: $comboId');
      print('Product ID: $productId');
      if (comboProductId != null) {
        print('Combo Product ID: $comboProductId');
      }
      print('=== END RESPONSE ===');

      if (response.statusCode == 200 || response.statusCode == 201) {
        final parsedData = jsonDecode(response.body);
        print('Success: ${parsedData.toString()}');
      } else {
        final parsedData = jsonDecode(response.body);
        print('Error: ${parsedData.toString()}');
        throw Exception(
            parsedData['message'] ?? 'Failed to update combo status');
      }
    } catch (e, stackTrace) {
      print('=== UPDATE COMBO STATUS ERROR ===');
      print('Error: $e');
      print('StackTrace: $stackTrace');
      print('Combo ID: $comboId');
      print('Product ID: $productId');
      if (comboProductId != null) {
        print('Combo Product ID: $comboProductId');
      }
      throw Exception('Error updating combo status: $e');
    }
  }

  Future<void> updateComboKitStatus({
    required num productId, // Outer product id (not combo_kit id)
    required String status, // 'active' or 'inactive'
    required WidgetRef ref,
    required BuildContext context,
  }) async {
    final uri = Uri.parse('${APIConfig.url}/combo-kits/$productId/status');

    print('=== UPDATE COMBO KIT STATUS API CALL ===');
    print('Method: PUT');
    print('URL: ${uri.toString()}');
    print('Product ID: $productId');
    print('Status: $status');
    print('Timestamp: ${DateTime.now()}');

    try {
      final response = await http.put(
        uri,
        headers: {
          'Accept': 'application/json',
          'Authorization': await getAuthToken(),
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'status': status,
        }),
      );

      print('=== UPDATE COMBO KIT STATUS API RESPONSE ===');
      print('Status Code: ${response.statusCode}');
      print('Response Body: ${response.body}');
      print('=== END RESPONSE ===');

      if (response.statusCode == 200 || response.statusCode == 201) {
        final parsedData = jsonDecode(response.body);
        print('Success: ${parsedData.toString()}');
        EasyLoading.showSuccess('Status updated successfully!');
      } else {
        final parsedData = jsonDecode(response.body);
        print('Error: ${parsedData.toString()}');
        EasyLoading.showError(
            parsedData['message'] ?? 'Failed to update combo status');
        throw Exception(
            parsedData['message'] ?? 'Failed to update combo status');
      }
    } catch (e, stackTrace) {
      print('=== UPDATE COMBO KIT STATUS ERROR ===');
      print('Error: $e');
      print('StackTrace: $stackTrace');
      EasyLoading.showError('Error updating combo status: $e');
      throw Exception('Error updating combo status: $e');
    }
  }
}